package comp2b;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

public class Main {

	public static void main(String[] args) {
		NameComparator nc = new NameComparator();
		Employee[] arr = {new Employee("Bob", 2000), 
				new Employee("Steve", 3000), 
				new Employee("Alice", 50000)};
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr, nc);
		System.out.println(Arrays.toString(arr));
		Employee e1 = arr[1]; 
		Employee bob = new Employee("Bob", 3000);
		System.out.println("Is e1 equal to bob? " + (e1.equals(bob)));
		System.out.println("Does compare think they're equal? " + (nc.compare(e1,  bob) == 0));
//		Arrays.sort(arr, new SalaryComparator());
//		System.out.println(Arrays.toString(arr));
	}
	//output:
	//[Bob: 2000, Steve: 3000, Alice: 50000]
	//[Alice: 50000, Bob: 2000, Steve: 3000]
	//[Bob: 2000, Steve: 3000, Alice: 50000]

}
