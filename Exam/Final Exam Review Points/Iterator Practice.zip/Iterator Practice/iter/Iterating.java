package iter;

import java.util.*;

public class Iterating {

	public static void main(String[] args) {
		List<String> list = Arrays.asList("A", "B", "C");
		Set<String> set = new HashSet<>();
		HashMap<String, String> h = new HashMap<>();
		
		//iterate through list
		for(String s: list) {
			prnt(s);
		}
		b();
		Iterator<String> it = list.iterator();
		while(it.hasNext()) {
			prnt(it.next());
		}
		b();
		
		set.addAll(list);
		
		//iterate through list
		for(String s: set) {
			prnt(s);
		}
		b();
		Iterator<String> it2 = set.iterator();
		while(it2.hasNext()) {
			prnt(it2.next());
		}
		b();
		
		h.put("A", "Albert");
		h.put("B", "Bob");
		h.put("C", "Carey");
		
		var entries = h.entrySet();
		prnt(entries.toString());
		b();
		
		Collection<String> values = h.values();
		prnt(values.toString());
		b();
		
		Set<String> keys = h.keySet();
		Iterator<String> it3 = keys.iterator();
		while(it3.hasNext()) {
			String nextkey = it3.next();
			String nextval = h.get(nextkey);
			prnt(nextval);
			
		}
		b();
		
		for(String key : keys) {
			String nextval = h.get(key);
			prnt(nextval);
		}
		b();
		
		for(String s : h.keySet()) {
			prnt(s);
		}
		b();
		
		for(String s : h.values()) {
			prnt(s);
		}
	}
	
	static void prnt(String x) {
		System.out.print(x + " ");
	}
	static void b() {
		System.out.println();
	}

}
