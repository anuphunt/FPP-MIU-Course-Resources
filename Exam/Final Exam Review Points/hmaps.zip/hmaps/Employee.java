package hmaps;

public class Employee implements Comparable<Employee> {
	// instance fields
	private String name;
	
	private int salary;
	

	// constructor
	Employee(String name,int aSalary) {
		this.name = name;
		salary = aSalary;
	}
	// instance methods
	public String getName() {
		return name;
	}
	
	public int getSalary() {
		return salary;
	}
	
	public String toString() {
		return name + ": " + salary;
	}

	@Override
	public int compareTo(Employee e) {
		if(name.compareTo(e.name) < 0) return -1;
		if(name.compareTo(e.name) > 0) return 1;
		else return 0;
		//return name.compareTo(e.name);
	}
	
}
