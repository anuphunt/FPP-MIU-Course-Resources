package hmaps;
import static org.junit.jupiter.api.Assertions.assertAll;

import java.util.*;
public class Main {
	HashMap<String, Employee[]> hmap = new HashMap<>();
	List<Employee[]> all;
	public static void main(String[] args) {
		Main m = new Main();

	}
	
	Main() {
		loadData();
		loadMap();
		printMap();
		
		
	}
	
	void loadData() {
		Employee[] arr1 = {new Employee("Bob", 20000), new Employee("Jim", 300000)};
		Employee[] arr2 = {new Employee("Steve", 20000), new Employee("Tom", 300000)};
		Employee[] arr3 = {new Employee("Dave", 20000), new Employee("Carol", 300000)};
		all = Arrays.asList(arr1, arr2, arr3);
		
	}
	
	void loadMap() {
		int count = 0;
		for(Employee[] emps : all) {
			hmap.put("" + count++, emps);
		}
	}
	void printMap() {
		for(Map.Entry entry : hmap.entrySet()) {
			System.out.print(entry.getKey() + " ");
			Employee[] val = (Employee[])entry.getValue();
			System.out.println(Arrays.toString(val));
		}
	}

}
