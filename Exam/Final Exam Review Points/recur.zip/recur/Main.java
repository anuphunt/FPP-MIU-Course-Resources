package recur;
import java.util.*;

/**
 * You are given an List of Integers. Use recursion to find the largest integer
 * in the array.
 * 
 * Use this strategy: Get the zeroth element Z of the list. Recursively
 * find the max M of the remaining list. Return the larger of M and Z.
 *
 */
public class Main {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(50);list.add(23); list.add(84); list.add(90); list.add(20);
		Main m = new Main();
		System.out.println(m.findMax(list));
	}
	
	public int findMax(List<Integer> list) {
		if(list.size() == 1) return list.get(0);
		int z = list.remove(0);
		int max = findMax(list);
		if(z > max) return z;
		else return max;
		
	}

}
