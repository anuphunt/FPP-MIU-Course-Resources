package midterm0312_solns.prob3_calculator;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculator extends JFrame {	
	private JPanel problemPanel;
	private JPanel buttonPanel;
	private JTextField first,second,sum;
	private JLabel plus, equal;
	private static final long serialVersionUID = 1L;
	public Calculator() {
		setTitle("Calculator");		
		//setSize(200,100);
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		defineProbPanel();
		defineButtonPanel();
		mainPanel.add(problemPanel,BorderLayout.NORTH);
		mainPanel.add(buttonPanel,BorderLayout.CENTER);
		getContentPane().add(mainPanel);
		pack();
	}
	private void defineProbPanel() {		
		problemPanel  = new JPanel();
		problemPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		first = new JTextField(5);
		second = new JTextField(5);
		sum = new JTextField(7);
		sum.setEditable(false);
		plus = new JLabel("+");
		equal = new JLabel("=");
		problemPanel.add(first);
		problemPanel.add(plus);
		problemPanel.add(second);
		problemPanel.add(equal);
		problemPanel.add(sum);
		
	}
	private void defineButtonPanel(){
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JButton addButn = new JButton("Add");
		addButn.addActionListener(new AddListener());
		
		JButton clearButn = new JButton("Clear");
		clearButn.addActionListener(new ClearListener());
		buttonPanel.add(addButn);
		buttonPanel.add(clearButn);
		
	}
	class AddListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int firstInt = Integer.parseInt(first.getText());
			int secondInt = Integer.parseInt(second.getText());
			sum.setText(""+(firstInt+secondInt));
		}
	}
	class ClearListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			first.setText("");
			second.setText("");
			sum.setText("");
		}
	}
	public static void main(String[] args){
		Calculator mf = new Calculator();
		mf.setVisible(true);
	}
}
