package midterm0312_solns.prob4_search;

public class SearchForString {
	private String[] arr;
	public SearchForString(String[] arr) {
		this.arr = arr;
		
	}
	public boolean search(String s){
		return recurSearch(s,arr.length-1);
	}
	private boolean recurSearch(String s, int upper){
		if(upper==0) return (s.equals(arr[0]));
		if(s.equals(arr[upper])) return true;
		return recurSearch(s,upper-1);
	}
	public static void main(String[] args) {
		String [] arr = {"Billy", "Steve", "Ralph", "Susan"};
		SearchForString sfs = new SearchForString(arr);
		System.out.println(sfs.search("Billy"));

	}

}
