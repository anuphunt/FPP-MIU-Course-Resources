package midterm0312_solns.prob1_vee_new;

class HatMaker extends Figure {
    
    public String getFigure() {
        return "/\\";
    }
}