package midterm0312_solns.prob1_vee_new;

class ParallelMaker extends Figure {

    public String getFigure() {
        return "||";
    }
}