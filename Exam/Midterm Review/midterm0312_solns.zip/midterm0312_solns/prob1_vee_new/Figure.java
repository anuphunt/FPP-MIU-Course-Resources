package midterm0312_solns.prob1_vee_new;

abstract class Figure {
    abstract public String getFigure();
    
}