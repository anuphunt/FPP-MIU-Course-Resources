package midterm0312_solns.prob1_vee_new;

class FaceMaker extends Figure {
 
    public String getFigure() {
        return ":)";
    }
}