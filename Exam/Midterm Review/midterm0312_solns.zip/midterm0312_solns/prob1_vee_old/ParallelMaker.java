package midterm0312_solns.prob1_vee_old;

class ParallelMaker {
 
    public String getFigure() {
        return "||";
    }
}