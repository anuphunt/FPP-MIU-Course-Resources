package midterm0312_solns.prob1_vee_old;

class HatMaker { 
    
    public String getFigure() {
        return "/\\";
    }
}