package midterm0312_solns.prob6_clone;

public class Enclosing implements Cloneable {
	public int outerval = 5;
	Inner inner  = new Inner();
	public Enclosing clone() throws CloneNotSupportedException {
		
		System.out.println("Inside Enclosing.clone()");
		Enclosing copy = (Enclosing)super.clone();
		Inner innerCopy = inner.clone();
		copy.inner = innerCopy;
		return copy;
	}
	class Inner implements Cloneable{
		int innerval = 6;
		Enclosing innerMethod() throws CloneNotSupportedException {
			Object copy = Enclosing.this.clone();
			System.out.println(copy.getClass().getName());
			return (Enclosing)copy;
			
		}
		@Override
		public Inner clone() throws CloneNotSupportedException {
			return (Inner)super.clone();
		}
	}
	public static void main(String[] args){
		Enclosing enclosing1 = new Enclosing();
		Enclosing.Inner inner1 = enclosing1.inner;
		try {
			Enclosing enclosing2 = inner1.innerMethod();
			enclosing2.outerval = 3;
			System.out.println("Value of outerval: " + enclosing1.outerval);
			
			enclosing2.inner.innerval = 2;
			System.out.println("Value of innerval: " + inner1.innerval);
			
		}
		catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
	}

}

