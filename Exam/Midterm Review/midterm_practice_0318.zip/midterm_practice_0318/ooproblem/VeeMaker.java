package midterm_practice_0318.ooproblem;

class VeeMaker {
    String figure = "\\/";
    
    public String getFigure() {
        return figure;
    }
}