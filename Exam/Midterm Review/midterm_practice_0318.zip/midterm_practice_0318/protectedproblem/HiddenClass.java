package midterm_practice_0318.protectedproblem;

//inside firstpackage
public class HiddenClass {
	private String val = "val";
	protected String getVal() {
		return val;
	}
}



