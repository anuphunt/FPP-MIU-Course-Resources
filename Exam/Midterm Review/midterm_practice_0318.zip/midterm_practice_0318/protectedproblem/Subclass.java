package midterm_practice_0318.protectedproblem;

//inside... firstpackage
public class Subclass extends HiddenClass {

}


