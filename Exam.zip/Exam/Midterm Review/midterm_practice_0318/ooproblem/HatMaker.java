package midterm_practice_0318.ooproblem;

class HatMaker {
     String figure = "/\\";
    
    public String getFigure() {
        return figure;
    }
}